from pathlib import Path
import datetime, hashlib, json, os, platform, subprocess, time
ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT/'work/round9-opportunity/source'
EVIDENCE = ROOT/'work/round9-opportunity/evidence'
WORK = ROOT/'work/round9-opportunity/full-fresh-bootstrap'
PYTHON = ROOT/'work/round8-pr3642-env/bin/python'
PACKAGE = 'research/staged-644-660-conditional-release'
PAIR = 'research/staged-644-660-width-reduction'
EXPECTED = '3efbb5de06a49ffeea6684482f2d3fe48cdca3fb'
env = dict(os.environ)
for key in ('GIT_ALTERNATE_OBJECT_DIRECTORIES', 'GIT_OBJECT_DIRECTORY', 'PYTHONPATH', 'PYTHONOPTIMIZE'):
    env.pop(key, None)
env.update(GIT_NO_REPLACE_OBJECTS='1', PYTHONDONTWRITEBYTECODE='1', OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1')
def git(*args):
    return subprocess.check_output(['git', '-C', str(SOURCE), *args], env=env)
def save(name, value):
    (EVIDENCE/name).write_text(json.dumps(value, indent=2, sort_keys=True)+'\n')
def snapshot():
    paths = set(git('ls-files', PACKAGE, PAIR).decode().splitlines())
    for package in (PACKAGE, PAIR):
        paths.update(json.loads((SOURCE/package/'VERIFY.json').read_text())['inputs'])
    blobs = {}
    for path in sorted(paths):
        data = (SOURCE/path).read_bytes()
        original = git('show', 'HEAD:'+path)
        if data != original:
            raise ValueError('working source differs from HEAD: '+path)
        blobs[path] = {'sha256': hashlib.sha256(data).hexdigest(), 'size': len(data), 'git_blob': hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()}
    return {'head': git('rev-parse', 'HEAD').decode().strip(), 'tracked_status': git('status', '--porcelain=v1', '--untracked-files=no').decode(), 'files': blobs}
pre = snapshot()
assert pre['head'] == EXPECTED and not pre['tracked_status']
assert not WORK.exists()
save('source-before.json', pre)
command = [str(PYTHON), '-B', str(SOURCE/PACKAGE/'reproduce.py'), '--repo', str(SOURCE), '--word-package', str(SOURCE/PAIR), '--work', str(WORK), '--jobs', '1']
record = {'command':command, 'cwd':str(SOURCE), 'source_head':EXPECTED, 'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(), 'runner_pid':os.getpid(), 'environment':{key:env[key] for key in ('GIT_NO_REPLACE_OBJECTS','PYTHONDONTWRITEBYTECODE','OPENBLAS_NUM_THREADS','OMP_NUM_THREADS')}, 'cleared_environment':['GIT_ALTERNATE_OBJECT_DIRECTORIES','GIT_OBJECT_DIRECTORY','PYTHONPATH','PYTHONOPTIMIZE'], 'platform':platform.platform(), 'python':subprocess.check_output([str(PYTHON),'--version'], text=True).strip(), 'dependencies':subprocess.check_output([str(PYTHON),'-m','pip','freeze'], text=True).splitlines()}
save('RUN.json', record)
start = time.monotonic()
with (EVIDENCE/'stdout.log').open('wb') as stdout, (EVIDENCE/'stderr.log').open('wb') as stderr:
    child = subprocess.Popen(command, cwd=SOURCE, env=env, stdout=stdout, stderr=stderr)
    record['child_pid'] = child.pid
    save('RUN.json', record)
    print(json.dumps({'started_at':record['started_at'], 'child_pid':child.pid, 'work':str(WORK), 'command':command}), flush=True)
    code = child.wait()
record.update(exit_code=code, elapsed_seconds=time.monotonic()-start, completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
post = snapshot()
save('source-after.json', post)
record.update(source_unchanged=pre==post, stdout_sha256=hashlib.sha256((EVIDENCE/'stdout.log').read_bytes()).hexdigest(), stderr_sha256=hashlib.sha256((EVIDENCE/'stderr.log').read_bytes()).hexdigest())
save('RUN.json', record)
print(json.dumps(record), flush=True)
raise SystemExit(code if pre==post else 99)
