import json,gzip,copy
from pathlib import Path
import staged_pair
D=Path(__file__).resolve().parent
for tag in ('base','extra'):
 read=lambda p:json.loads(gzip.decompress(p.read_bytes()))
 p=read(D/f'inputs/PRE3605-{tag}.json.gz');r=read(D/f'staged3605/RECORD-{tag}.json.gz');w=read(D/f'words/BORROW-WORD-43{tag}.json.gz')
 assert staged_pair.apply(p,r)==w
 bad=copy.deepcopy(r);bad['B_deleted'][0]['old'][3]+=1
 try:staged_pair.apply(p,bad)
 except ValueError:pass
 else:raise AssertionError('wrong preimage accepted')
print('PASS_STAGED3605_RECONSTRUCTION_AND_CONTROL')
