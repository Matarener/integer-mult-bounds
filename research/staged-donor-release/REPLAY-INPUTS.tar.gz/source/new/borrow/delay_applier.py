"""Commute two releases to their first producer, preserving all other frames."""
import copy,gzip,json
from pathlib import Path
from collections import Counter
from staged_pair import cleanup

def build(w):
 x=copy.deepcopy(w);at={}
 for j,rec in enumerate(w['warps']):at.setdefault(rec[0],[]).append((j,copy.deepcopy(rec)))
 moves={}
 for h,d,q in [(644,640,2),(660,656,-1)]:
  start=next(i for i,g in enumerate(w['B']) if g[:5]==['add',d,h,q,1])
  stop=next(i for i in range(start+1,len(w['B'])) if w['B'][i][1]==h)
  for i in range(start+1,stop):
   g=w['B'][i]
   if g[0]=='add':assert g[1]!=h and g[2]!=d
   else:assert g[1] not in (h,d)
   assert all(r[1][1] not in (h,d) for r in at.get(i,[]))
  assert all(r[1][1] not in (h,d) for r in at.get(stop,[]))
  moves[start]=(stop,['add',d,h,q,1,w['B'][stop][-1]])
 b=[];warps=[None]*len(w['warps'])
 for i in range(len(w['B'])+1):
  for j,rec in at.get(i,[]):rec[0]=len(b);warps[j]=rec
  for stop,g in moves.values():
   if i==stop:b.append(copy.deepcopy(g))
  if i<len(w['B']) and i not in moves:b.append(copy.deepcopy(w['B'][i]))
 x['B']=b;x['warps']=warps;x['cleanup']=cleanup(x)
 bill={1:2437,2:724,3:226,4:102,5:20,8:8};inv={4:26,5:2,6:18,7:52,8:97,9:213}
 assert w['report']['local_profile']=={'1':2439,'2':726,'3':224,'4':102,'5':20,'8':8}
 x['report']['local_profile']={str(k):v for k,v in bill.items()}
 return x,dict(bill=bill,inventory=inv,moves=moves,delta=dict(Counter(bill)-Counter()))


# Explicit final declared stage; source pin checked by literal predecessor chain.
def apply(w):
 return build(w)[0]
